// Migration non destructive : les anciennes clés de stockage restent intactes.
export function migrateLegacy(record,catalog){
 const equipment={};for(const [part,id] of Object.entries(record.gearItems||{})){
  if(part==='charm'||!id)continue;
  equipment[part]=(part==='weapon'?'weapon-':'armor-')+id;
 }
 const decorations=(record.jewelPlacements||[]).map(d=>({decorationId:'gem-'+d.decorationId,slotId:equipment[d.part]+'-'+d.slot}));
 const result={catalogVersion:catalog.version,equipment,decorations,notes:record.notes||'',legacyRecord:record};
 if(record.gearItems?.charm){const charm=catalog.charms?.find(c=>c.id==='charm-'+record.gearItems.charm);if(!charm)throw Error('Talisman absent du catalogue ; archive conservée.');result.talisman=structuredClone(charm)}
 return result;
}
