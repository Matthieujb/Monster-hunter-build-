// Projection perspective de la même scène 3D, sans dépendance à WebGL.
// Modèle low-poly : tri des faces par profondeur, éclairage diffus par face.
export function createSoftwareRenderer(THREE) {
 const canvas=document.createElement('canvas');
 const ctx=canvas.getContext('2d',{alpha:true});
 if(!ctx)throw new Error('Canvas indisponible');
 let width=1,height=1,ratio=1;
 const a=new THREE.Vector3(),b=new THREE.Vector3(),c=new THREE.Vector3();
 const normal=new THREE.Vector3(),edge=new THREE.Vector3();
 const light=new THREE.Vector3(3,6,5).normalize();
 return {
  domElement:canvas,
  setPixelRatio(value){ratio=Math.min(value,1.5)},
  setClearColor(){},
  setSize(w,h){width=w;height=h;canvas.width=Math.round(w*ratio);canvas.height=Math.round(h*ratio)},
  render(scene,camera){
   scene.updateMatrixWorld(true);camera.updateMatrixWorld(true);
   const faces=[];
   scene.traverseVisible(object=>{
    if(!object.isMesh)return;
    const geometry=object.geometry,position=geometry.attributes.position,index=geometry.index;
    const count=index?index.count:position.count;
    for(let i=0;i<count;i+=3){
     a.fromBufferAttribute(position,index?index.getX(i):i).applyMatrix4(object.matrixWorld);
     b.fromBufferAttribute(position,index?index.getX(i+1):i+1).applyMatrix4(object.matrixWorld);
     c.fromBufferAttribute(position,index?index.getX(i+2):i+2).applyMatrix4(object.matrixWorld);
     normal.subVectors(b,a).cross(edge.subVectors(c,a)).normalize();
     if(normal.dot(edge.subVectors(camera.position,a))<=0)continue;
     const shade=.48+.52*Math.max(0,normal.dot(light));
     const color=object.material.color.clone().multiplyScalar(shade).getStyle();
     a.project(camera);b.project(camera);c.project(camera);
     if([a,b,c].some(v=>!Number.isFinite(v.x)||v.z< -1||v.z>1))continue;
     faces.push({depth:(a.z+b.z+c.z)/3,color,points:[a.x,a.y,b.x,b.y,c.x,c.y]});
    }
   });
   faces.sort((a,b)=>b.depth-a.depth);
   ctx.setTransform(ratio,0,0,ratio,0,0);ctx.clearRect(0,0,width,height);
   for(const face of faces){
    ctx.beginPath();
    for(let i=0;i<6;i+=2){const x=(face.points[i]+1)*width/2,y=(1-face.points[i+1])*height/2;i?ctx.lineTo(x,y):ctx.moveTo(x,y)}
    ctx.closePath();ctx.fillStyle=face.color;ctx.fill();
   }
  },
  dispose(){canvas.width=canvas.height=1}
 };
}
