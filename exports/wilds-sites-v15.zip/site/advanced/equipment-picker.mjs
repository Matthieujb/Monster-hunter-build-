export const weaponLabels={bow:'Arc','charge-blade':'Volto-hache','dual-blades':'Doubles lames','great-sword':'Grande épée',gunlance:'Lancecanon',hammer:'Marteau','heavy-bowgun':'Fusarbalète lourd','hunting-horn':'Corne de chasse','insect-glaive':'Insectoglaive',lance:'Lance','light-bowgun':'Fusarbalète léger','long-sword':'Épée longue','switch-axe':'Morpho-hache','sword-shield':'Épée et bouclier'};
const normalize=v=>String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('fr');
export function filterEquipment(catalog,part,{query='',weaponKind='',rank=''}={}){
 const terms=normalize(query).trim().split(/\s+/).filter(Boolean),skills=new Map(catalog.skills.map(s=>[s.id,s.name]));
 return catalog.equipment.filter(item=>item.part===part&&(!weaponKind||item.weaponKind===weaponKind)&&(!rank||item.rank===rank)&&terms.every(term=>normalize(item.name+' '+(item.setName||'')+' '+Object.keys(item.skills||{}).map(id=>skills.get(id)||'').join(' ')).includes(term))).sort((a,b)=>(b.rarity||0)-(a.rarity||0)||a.name.localeCompare(b.name,'fr'));
}
export function replaceEquipment(build,catalog,part,id){
 const item=id?catalog.equipment.find(e=>e.id===id):null;
 if(id&&(!item||item.part!==part))throw Error('Cette pièce ne correspond pas à cet emplacement.');
 if(build.equipment?.[part]===id)return structuredClone(build);
 const previous=catalog.equipment.find(e=>e.id===build.equipment?.[part]),slots=new Set((previous?.slots||[]).map(s=>s.id));
 return {...build,equipment:{...build.equipment,[part]:id},decorations:(build.decorations||[]).filter(d=>!slots.has(d.slotId))};
}
