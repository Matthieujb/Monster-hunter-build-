import {filterEquipment,replaceEquipment,weaponLabels} from './equipment-picker.mjs';
import {migrateLegacy} from './legacy-builds.mjs';
import {validateBuild} from './validate-build.mjs';
import {estimatePhysicalDamage} from './damage-engine.mjs';
import {optimizeEquipment} from './build-optimizer.mjs';
import {saveBuild,listBuilds,removeBuild} from './build-library.mjs';
import {optimizeDecorations,compareBuilds,encodeShare,decodeShare,validateCustomTalisman} from './builder-features.mjs';
const snapshots=[];
function setupAdvanced(){
 const skillOptions=()=>catalog.skills.map(s=>'<option value="'+s.id+'">'+s.name.replaceAll('&','&amp;').replaceAll('<','&lt;')+'</option>').join('');
 const talisman=$('talismanEditor');talisman.replaceChildren();
 for(let i=0;i<3;i++){const line=el('div','editor-row');const skill=el('select');skill.id='talismanSkill'+i;skill.append(new Option('— Aucun —',''));for(const s of catalog.skills.filter(x=>!['set','group'].includes(x.kind)))skill.append(new Option(s.name,s.id));const lvl=el('input');lvl.id='talismanLevel'+i;lvl.type='number';lvl.min='1';lvl.max='10';lvl.value='1';lvl.setAttribute('aria-label','Niveau du talent '+(i+1));line.append(skill,lvl);talisman.append(line)}
 $('applyTalisman').onclick=()=>{const skills={};for(let i=0;i<3;i++){const id=$('talismanSkill'+i).value;if(id)skills[id]=Number($('talismanLevel'+i).value)}const t={skills,verificationStatus:'provisional'};const errors=validateCustomTalisman(t,catalog);$('talismanMessage').textContent=errors.join(' ')||'Talisman enregistré, non certifié.';if(errors.length)return;build.talisman=t;render()};
 const goals=$('goalEditor');goals.replaceChildren();for(const s of catalog.skills.filter(x=>!['set','group'].includes(x.kind))){const line=el('label','goal-row');line.append(el('span','',s.name));const n=el('input');n.type='number';n.min='0';n.max=String(s.maxLevel);n.value='0';n.dataset.skill=s.id;line.append(n);goals.append(line)}
 $('optimizeBtn').onclick=async()=>{const goals={};for(const n of $('goalEditor').querySelectorAll('input')){const v=Number(n.value);if(v>0)goals[n.dataset.skill]=Math.min(v,Number(n.max))}if(!Object.keys(goals).length){$('optimizeResult').textContent='Sélectionnez au moins un talent.';return}let result;try{result=await runOptimization('gems',goals)}catch(e){$('optimizeResult').textContent=e.message;return}if(result.build){build=result.build;render()}$('optimizeResult').textContent=(result.complete?'Objectifs atteints. ':'Objectifs non atteints. ')+result.explored+' combinaisons explorées'+(result.truncated?' (limite atteinte).':'')+' Résultat non certifié.'};
 $('applyWeapon').onclick=()=>{const system=$('weaponSystem').value;build.weaponConfiguration=system?{system,notes:$('weaponNotes').value,verificationStatus:'example-only'}:{};render()};
 $('snapshotBtn').onclick=()=>{if(snapshots.length===3){$('compareResult').textContent='Trois montages déjà épinglés. Le plus ancien est remplacé.';snapshots.shift()}snapshots.push(structuredClone(build));$('compareResult').textContent=snapshots.length+' montage(s) épinglé(s).'};
 $('compareBtn').onclick=()=>{const records=snapshots.length?snapshots:[build];const reports=records.map(b=>validateBuild(b,catalog));const target=$('compareResult');target.replaceChildren();const table=el('table'),head=el('tr');head.append(el('th','','Talent'));records.forEach((b,i)=>head.append(el('th','','Montage '+(i+1))));table.append(head);for(const id of new Set(reports.flatMap(r=>Object.keys(r.effectiveSkills)))){const row=el('tr');row.append(el('th','',catalog.skills.find(s=>s.id===id)?.name||id));for(const r of reports)row.append(el('td','',String(r.effectiveSkills[id]||0)));table.append(row)}target.append(table)};
 $('shareBtn').onclick=async()=>{const url=new URL(location.href);url.hash='build='+encodeShare(build);try{await navigator.clipboard.writeText(url.href);$('compareResult').textContent='Lien copié.'}catch{$('compareResult').textContent=url.href}};
 try{const params=new URLSearchParams(location.hash.slice(1));const token=params.get('build');if(token){const imported=decodeShare(token);if(imported.catalogVersion===catalog.version){build=imported;render();$('compareResult').textContent='Build importé depuis le lien.'}else $('compareResult').textContent='Version du catalogue incompatible avec le lien.'}}catch(e){$('compareResult').textContent='Lien invalide : '+e.message}
}

const read=async name=>{const r=await fetch('./'+name);if(!r.ok)throw new Error('Chargement de '+name);return r.json()};
const $=id=>document.getElementById(id);
const partLabels={weapon:'Arme',head:'Tête',chest:'Torse',arms:'Bras',waist:'Taille',legs:'Jambes'};
let catalog, build, part='head',hunterViewer=null,recipes=[]; const lockedParts=new Set();
const localKey='wilds-advanced-build-v2';
function defaultBuild(){return {catalogVersion:catalog.version,equipment:{},decorations:[]};}
function itemFor(p){return catalog.equipment.find(e=>e.id===build.equipment[p])}
function el(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n}
function render(){
 if(hunterViewer)hunterViewer.equip(build,catalog);
 const picker=$('equipmentPicker');if(picker){picker.replaceChildren();picker.append(new Option('— Aucune pièce —',''));const q=($('equipmentSearch').value||'').toLocaleLowerCase('fr');for(const item of catalog.equipment.filter(x=>x.part===part && (!q||(x.name+' '+Object.keys(x.skills||{}).map(id=>catalog.skills.find(s=>s.id===id)?.name||'').join(' ')).toLocaleLowerCase('fr').includes(q)) || x.id===build.equipment[part]))picker.append(new Option(item.name,item.id));picker.value=build.equipment[part]||'';picker.onchange=()=>{build=replaceEquipment(build,catalog,part,picker.value);$('equipmentSuggestions').replaceChildren();render()};}

 $('equipmentList').replaceChildren();
 for(const [p,label] of Object.entries(partLabels)){
  const e=itemFor(p),b=el('button','equipment-button'+(p===part?' active':''));b.type='button';b.dataset.part=p;b.setAttribute('aria-label','Choisir : '+label);b.setAttribute('aria-haspopup','dialog');const t=el('span');t.append(el('strong','',label),el('small','',e?.name||'Aucune pièce'));b.append(el('span','symbol','◇'),t,el('span','','›'));b.addEventListener('click',()=>{openEquipmentPicker(p)});$('equipmentList').append(b);
 }
 $('lockPiece').checked=lockedParts.has(part);const e=itemFor(part);$('selectedPiece').textContent=e?.name||'Aucune pièce';$('slots').replaceChildren();
 for(const slot of e?.slots||[]){
  const row=el('div','slotrow'),lab=el('label'),txt=el('span','',`Emplacement ${slot.kind==='weapon'?'arme':'armure'}`),sz=el('span','slot-size','◇'.repeat(slot.size));lab.append(txt,sz);
  const select=el('select');select.setAttribute('aria-label',`Joyau pour ${slot.id}`);select.append(new Option('— Aucun joyau —',''));
  for(const gem of catalog.decorations.filter(x=>x.kind===slot.kind&&x.size<=slot.size))select.append(new Option(`${gem.name} · taille ${gem.size}`,gem.id));
  const selected=build.decorations.find(x=>x.slotId===slot.id);select.value=selected?.decorationId||'';
  select.addEventListener('change',()=>{build.decorations=build.decorations.filter(x=>x.slotId!==slot.id);if(select.value)build.decorations.push({slotId:slot.id,decorationId:select.value});render()});row.append(lab,select);$('slots').append(row);
 }
 const v=validateBuild(build,catalog);if($('buildSummary'))$('buildSummary').textContent=`${Object.values(build.equipment).filter(Boolean).length} pièces · ${build.decorations.length} joyau(x) · ${v.activeSetBonuses.length} bonus de set`;$('status').textContent=v.status==='valid'?'STRUCTURE VALIDE':v.status==='incomplete'?'INCOMPLET':'INCOMPATIBLE';$('status').className=v.status==='invalid'?'invalid':'';$('certification').textContent=v.certified?'Données certifiées':'Catalogue communautaire non certifié';$('errorCount').textContent=v.errors.length;$('warningCount').textContent=v.warnings.length;
 for(const [id,items,empty] of [['errors',v.errors,'Aucune erreur détectée'],['warnings',v.warnings,'Aucun avertissement']]){const ul=$(id);ul.replaceChildren();for(const x of items)ul.append(el('li','',x.message));if(!items.length)ul.append(el('li','',empty));}
 $('skills').replaceChildren();const entries=Object.entries(v.effectiveSkills);if(!entries.length)$('skills').append(el('p','smalltext','Aucun talent renseigné.'));for(const [id,lvl] of entries){const skill=catalog.skills.find(x=>x.id===id);const row=el('div','skillrow');row.append(el('span','',skill?.name||id),el('span','pips',`${lvl}/${skill?.maxLevel||'?'}${v.rawSkills[id]>lvl?' · +'+(v.rawSkills[id]-lvl)+' inutilisé(s)':''}`));$('skills').append(row)}
 renderCrafting();
 const equipped=Object.values(build.equipment).map(id=>catalog.equipment.find(e=>e.id===id)).filter(Boolean);
 $('equipmentStats').textContent='Défense de base : '+equipped.reduce((n,e)=>n+(e.defense||0),0)+' · Emplacements libres : '+(equipped.reduce((n,e)=>n+e.slots.length,0)-build.decorations.length);
 $('activeBonuses').textContent='Bonus actifs : '+([...new Set(v.activeSetBonuses.map(id=>catalog.setBonuses.find(b=>b.id===id)?.name))].join(', ')||'aucun');

}
function gemCards(){const q=$('searchGem').value.toLocaleLowerCase('fr-FR'),kind=$('gemType').value;const target=$('gemCards');target.replaceChildren();for(const gem of catalog.decorations.filter(g=>(kind==='all'||g.kind===kind)&&g.name.toLocaleLowerCase('fr-FR').includes(q))){const c=el('div','gemcard'),icon=el('div','gem-icon'+(gem.kind==='weapon'?' weapon':''),'◇'),t=el('div');t.append(el('strong','',gem.name),el('small','',`Taille ${gem.size} · ${gem.kind==='weapon'?'Arme':'Armure'}`));c.append(icon,t);target.append(c)} }
function damage(){try{const x=estimatePhysicalDamage({trueRaw:Number($('attack').value),motionValue:Number($('motion').value),hitzone:Number($('hitzone').value),sharpness:Number($('sharpness').value),affinity:Number($('affinity').value),criticalMultiplier:Number($('criticalMultiplier').value),otherMultiplier:Number($('otherMultiplier').value)});$('damageValue').textContent=x.expected.toFixed(1)}catch(e){$('damageValue').textContent='Paramètres invalides'}}
async function init(){try {const [manifest,equipment,decorations,skills,setBonuses,charms]=await Promise.all(['manifest.json','equipment.json','decorations.json','skills.json','set-bonuses.json','charms.json'].map(read));catalog={manifest,version:manifest.catalogVersion,equipment,decorations,skills,setBonuses,charms};build=defaultBuild();$('version').textContent=catalog.version;render();gemCards();damage();setupAdvanced();setupLibraryAndOptimizer();setupUnified();loadBestiaryAndCrafting();loadHunter3D();}catch(e){$('status').textContent='CHARGEMENT IMPOSSIBLE';$('selectedPiece').textContent=String(e);console.error(e)}}
$('menuToggle').addEventListener('click',()=>{const show=$('navigation').classList.toggle('open');$('menuToggle').setAttribute('aria-expanded',String(show))});document.querySelectorAll('nav a').forEach(a=>a.addEventListener('click',()=>{$('navigation').classList.remove('open');document.querySelectorAll('nav a').forEach(x=>x.classList.toggle('active',x===a))}));
$('saveBtn').addEventListener('click',()=>{if(!build)return;localStorage.setItem(localKey,JSON.stringify(build));alert('Build sauvegardé sur ce navigateur.')});
$('loadBtn').addEventListener('click',()=>{try{const saved=JSON.parse(localStorage.getItem(localKey));if(!saved){alert('Aucune sauvegarde.');return}if(saved.catalogVersion!==catalog.version)throw Error('Catalogue incompatible');if(!saved.equipment||!Array.isArray(saved.decorations))throw Error('Format invalide');build=saved;render()}catch(e){alert('Chargement impossible : '+e.message)}});
$('clearBtn').addEventListener('click',()=>{if(!catalog)return;build=defaultBuild();render()});$('searchGem').addEventListener('input',gemCards);$('gemType').addEventListener('change',gemCards);for(const id of ['attack','motion','hitzone','sharpness','affinity','criticalMultiplier','otherMultiplier'])$(id).addEventListener('input',damage);if($('copyBtn'))$('copyBtn').addEventListener('click',()=>{const blob=new Blob([JSON.stringify(build,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='wilds-build.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)});init();

async function loadHunter3D(){
 const host=$('hunter3d'),status=$('hunter3dStatus'),fallback=$('hunterFallback');
 if(!host)return;
 try{
  const {createHunterViewer}=await import('./hunter-viewer.mjs');
  hunterViewer=await createHunterViewer(host);
  hunterViewer.equip(build,catalog);
  fallback.hidden=true;status.textContent=(hunterViewer.mode==='software'?'3D compatible · ':'3D · ')+'Glisser pour tourner · Pincer pour zoomer';
  $('hunterZoomIn').onclick=()=>hunterViewer.zoomIn();
  $('hunterZoomOut').onclick=()=>hunterViewer.zoomOut();
  $('hunterReset').onclick=()=>hunterViewer.reset();
 }catch(error){console.warn('Visualiseur 3D indisponible',error);host.hidden=true;fallback.hidden=false;status.textContent='Mode 2D : WebGL ou connexion 3D indisponible';}
}

function setupLibraryAndOptimizer(){
 const target=$('buildLibrary');
 const refresh=()=>{target.replaceChildren();for(const record of listBuilds(localStorage)){const row=el('div','editor-row');const load=el('button','secondary',record.name);load.type='button';load.onclick=()=>{if(record.build.catalogVersion!==catalog.version){alert('Catalogue incompatible.');return}build=structuredClone(record.build);render()};const remove=el('button','secondary','Supprimer');remove.type='button';remove.onclick=()=>{removeBuild(localStorage,record.id);refresh()};row.append(load,remove);target.append(row)}if(!target.children.length)target.textContent='Aucun montage enregistré.'};
 $('librarySave').onclick=()=>{try{saveBuild(localStorage,build,{name:$('buildName').value||'Montage sans nom'});refresh()}catch(e){alert(e.message)}};refresh();
 $('optimizeEquipmentBtn').onclick=async()=>{const goals={};for(const n of $('goalEditor').querySelectorAll('input')){const v=Number(n.value);if(v>0)goals[n.dataset.skill]=Math.min(v,Number(n.max))}if(!Object.keys(goals).length){$('equipmentOptimizeResult').textContent='Sélectionnez un objectif dans OPTIMISEUR DPS / CONFORT.';return}
 let result;try{result=await runOptimization('equipment',goals)}catch(e){$('equipmentOptimizeResult').textContent=e.message;return}
 if(result.build){build=result.build;render()}
 $('equipmentOptimizeResult').textContent=(result.complete?'Objectifs atteints. ':'Objectifs non atteints. ')+result.explored+'/'+result.total+' ensembles explorés.'+(result.truncated||result.gemSearchTruncated?' Recherche partielle.':'')+' Recherche exploratoire plafonnée : résultat non certifié.';
 };
}
async function loadBestiaryAndCrafting(){
 try{
  const data=await read('bestiary.json'),target=$('bestiaryList');target.replaceChildren();
  const tools=el('div','filterbar'),search=document.createElement('input'),rank=document.createElement('select');
  search.type='search';search.placeholder='Monstre ou matériau…';search.setAttribute('aria-label','Rechercher monstre ou matériau');
  for(const [value,label] of [['all','Tous les rangs'],['Novice','Novice'],['Expert','Expert']]){const opt=document.createElement('option');opt.value=value;opt.textContent=label;rank.append(opt)}
  tools.append(search,rank);target.append(tools);
  const results=el('div','bestiary-results');target.append(results);
  const renderList=()=>{results.replaceChildren();const q=search.value.toLocaleLowerCase('fr').trim();let count=0;
   for(const monster of data.monsters||[]){
    const matching=monster.materials.filter(m=>(rank.value==='all'||m.rank===rank.value)&&(!q||monster.name.toLocaleLowerCase('fr').includes(q)||m.name.toLocaleLowerCase('fr').includes(q)));
    if(!matching.length)continue;count++;
    const card=document.createElement('details');card.className='bestiary-card';card.open=!!q;
    const summary=document.createElement('summary');summary.textContent=monster.name+' · '+matching.length+' voies de butin';card.append(summary);
    const table=document.createElement('table');table.className='loot-table';const thead=document.createElement('thead'),tr=document.createElement('tr');
    for(const title of ['Matériau','Rang','Obtention','Chance']){const th=document.createElement('th');th.textContent=title;tr.append(th)}thead.append(tr);table.append(thead);
    const tbody=document.createElement('tbody');for(const m of matching){const row=document.createElement('tr');for(const value of [m.name,m.rank,m.method,(m.chance==null?'À vérifier':m.chance+' %')]){const td=document.createElement('td');td.textContent=value;row.append(td)}tbody.append(row)}table.append(tbody);card.append(table);
    const link=document.createElement('a');link.href=monster.source;link.target='_blank';link.rel='noopener noreferrer';link.textContent='Consulter la source';card.append(link);results.append(card);
   }if(!count)results.textContent='Aucun matériau trouvé pour cette recherche.';
  };
  search.addEventListener('input',renderList);rank.addEventListener('change',renderList);renderList();
  const disclaimer=el('p','smalltext',data.disclaimer);target.append(disclaimer);
 }catch(e){$('bestiaryList').textContent='Bestiaire indisponible : '+e.message}
 try{const data=await read('crafting.json');recipes=data.recipes||[];renderCrafting()}catch(e){$('craftingList').textContent='Recettes indisponibles : '+e.message}
}

function setupUnified(){
 setupEquipmentPicker();
 $('importBuild').onchange=async()=>{try{const file=$('importBuild').files[0];if(!file)return;if(file.size>200000)throw Error('Fichier trop volumineux');const imported=JSON.parse(await file.text());if(imported.catalogVersion!==catalog.version)throw Error('Catalogue incompatible');const report=validateBuild(imported,catalog);if(report.errors.length)throw Error(report.errors.map(e=>e.message).join(' · '));build=imported;render();$('importMessage').textContent='Build importé. Vous pouvez le sauvegarder.'}catch(e){$('importMessage').textContent='Import refusé : '+e.message}};
 $('suggestEquipment').onclick=()=>{
  const goals={};for(const n of $('goalEditor').querySelectorAll('input'))if(Number(n.value)>0)goals[n.dataset.skill]=Number(n.value);
  const target=$('equipmentSuggestions');target.replaceChildren();if(!Object.keys(goals).length){target.textContent='Choisissez d’abord les talents souhaités dans l’optimiseur.';return}
  const oldSlots=new Set((itemFor(part)?.slots||[]).map(s=>s.id));
  const ranked=catalog.equipment.filter(e=>e.part===part&&e.id!==build.equipment[part]).map(item=>{const candidate={...build,equipment:{...build.equipment,[part]:item.id},decorations:build.decorations.filter(d=>!oldSlots.has(d.slotId))};const result=validateBuild(candidate,catalog);const score=Object.entries(goals).reduce((sum,[id,n])=>sum+Math.min(n,result.effectiveSkills[id]||0),0);return {item,score}}).sort((a,b)=>b.score-a.score||b.item.defense-a.item.defense).slice(0,5);
  for(const {item,score} of ranked){const button=el('button','secondary',item.name+' · '+score+' niveau(x) ciblé(s)');button.onclick=()=>{build.equipment[part]=item.id;build.decorations=build.decorations.filter(d=>!oldSlots.has(d.slotId));target.replaceChildren();render()};target.append(button)}
 };
 $('equipmentSearch').oninput=render;
 $('lockPiece').onchange=()=>{$('lockPiece').checked?lockedParts.add(part):lockedParts.delete(part)};
 $('goalSearch').oninput=()=>{const q=$('goalSearch').value.toLocaleLowerCase('fr');for(const row of $('goalEditor').children)row.hidden=!row.textContent.toLocaleLowerCase('fr').includes(q)};
 {const charms=catalog.charms;const picker=$('charmPicker');for(const c of charms)picker.append(new Option(c.name,c.id));picker.onchange=()=>{build.talisman=charms.find(c=>c.id===picker.value)||undefined;render()}};
 const root=$('legacyBuilds');
 try{const records=JSON.parse(localStorage.getItem('wilds-builds')||'[]');for(const record of records){const button=el('button','secondary',record.title||'Ancien montage');button.onclick=()=>{try{build=migrateLegacy(record,catalog);$('buildName').value=record.title||'';render();$('migrationMessage').textContent='Montage chargé. Vérifiez les éventuelles incompatibilités avant de l’enregistrer dans la bibliothèque.'}catch(e){$('migrationMessage').textContent=e.message}};root.append(button)}if(!records.length)root.textContent='Aucun ancien montage sur cet appareil.'}catch{root.textContent='Archives illisibles ; les données originales sont conservées.'}
 $('exportLegacy').onclick=()=>{const blob=new Blob([localStorage.getItem('wilds-builds')||'[]'],{type:'application/json'});const url=URL.createObjectURL(blob),a=el('a');a.href=url;a.download='wilds-anciens-builds.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};
 const params=new URLSearchParams(location.search),ref=params.get('equipment');if(ref){const [type,id]=ref.split(':');if(type==='charm'){build.talisman=catalog.charms.find(c=>c.id==='charm-'+id);render();return}const item=catalog.equipment.find(x=>x.id===(type==='weapon'?'weapon-':'armor-')+id);if(item){part=item.part;build.equipment[part]=item.id;render()}}
}

function runOptimization(kind,goals){
 return new Promise((resolve,reject)=>{
  let worker;try{worker=new Worker(new URL('./optimizer-worker.mjs',import.meta.url),{type:'module'})}catch{reject(Error('Recherche indisponible dans ce navigateur.'));return}
  const before=JSON.stringify(build),button=$('cancelOptimization');
  $('optimizeBtn').disabled=$('optimizeEquipmentBtn').disabled=true;button.hidden=false;
  $('optimizationStatus').textContent='Recherche en cours… Vous pouvez continuer à consulter le montage.';
  const finish=()=>{clearTimeout(timer);worker.terminate();$('optimizeBtn').disabled=$('optimizeEquipmentBtn').disabled=false;button.hidden=true;$('optimizationStatus').textContent='Recherche terminée.'};
  const timer=setTimeout(()=>{finish();reject(Error('Recherche interrompue après 20 secondes. Réduisez les objectifs ou verrouillez davantage de pièces.'))},20000);
  button.onclick=()=>{finish();reject(Error('Recherche annulée. Montage conservé.'))};
  worker.onerror=()=>{finish();reject(Error('Erreur du moteur de recherche. Montage conservé.'))};
  worker.onmessage=({data})=>{finish();if(data.error)reject(Error(data.error));else if(JSON.stringify(build)!==before)reject(Error('Le montage a changé pendant la recherche : résultat non appliqué.'));else resolve(data.result)};
  worker.postMessage({kind,build,catalog,goals,lockedParts:[...lockedParts]});
 });
}

function renderCrafting(){
 const target=$('craftingList');if(!target)return;target.replaceChildren();
 const selected=Object.values(build?.equipment||{});let count=0;
 for(const recipe of recipes.filter(r=>selected.includes(r.equipmentId))){count++;const block=el('details'),title=el('summary','',recipe.name+' · '+recipe.method);block.append(title);for(const m of recipe.materials)block.append(el('p','smalltext',m.name+' × '+m.quantity));target.append(block)}
 if(!count)target.textContent='Équipez une pièce pour consulter ses matériaux. Une recette absente du catalogue ne signifie pas une fabrication gratuite.';
}

let pickerLimit=40;
function openEquipmentPicker(selectedPart){
 part=selectedPart;$('equipmentSearch').value='';$('equipmentSuggestions').replaceChildren();render();
 $('gearDialogTitle').textContent='Choisir — '+partLabels[part];
 $('gearSearch').value='';$('gearKind').value='';$('gearRank').value='';pickerLimit=40;
 $('gearKindLabel').hidden=part!=='weapon';$('gearRankLabel').hidden=part==='weapon';
 renderEquipmentChoices();$('gearDialog').showModal();
}
function setupEquipmentPicker(){
 for(const [value,label] of Object.entries(weaponLabels))$('gearKind').append(new Option(label,value));
 for(const id of ['gearSearch','gearKind','gearRank'])$(id).addEventListener(id==='gearSearch'?'input':'change',()=>{pickerLimit=40;renderEquipmentChoices()});
 $('gearMore').onclick=()=>{pickerLimit+=40;renderEquipmentChoices()};
 $('gearClose').onclick=()=>$('gearDialog').close();
 $('gearRemove').onclick=()=>{build=replaceEquipment(build,catalog,part,'');render();$('gearDialog').close()};
 $('gearDialog').addEventListener('close',()=>document.querySelector('[data-part="'+part+'"]')?.focus());
 $('openGearPicker').onclick=()=>openEquipmentPicker(part);
}
function renderEquipmentChoices(){
 const list=filterEquipment(catalog,part,{query:$('gearSearch').value,weaponKind:$('gearKind').value,rank:$('gearRank').value});
 const target=$('gearResults');target.replaceChildren();
 $('gearCount').textContent=list.length+' pièce(s) · '+Math.min(pickerLimit,list.length)+' affichée(s)';
 for(const item of list.slice(0,pickerLimit)){
  const button=el('button','gear-choice');button.type='button';button.setAttribute('aria-label','Équiper '+item.name);button.setAttribute('aria-pressed',String(build.equipment[part]===item.id));
  button.append(el('strong','',item.name),el('span','gear-meta','Rareté '+item.rarity+' · '+(item.part==='weapon'?(weaponLabels[item.weaponKind]||'Arme'):'Défense '+item.defense)),el('span','gear-meta','Emplacements : '+(item.slots.map(s=>'['+s.size+']').join(' ')||'aucun')));
  button.append(el('span','gear-skills',Object.entries(item.skills||{}).map(([id,level])=>(catalog.skills.find(s=>s.id===id)?.name||id)+' '+level).join(' · ')||'Aucun talent natif'));
  button.onclick=()=>{build=replaceEquipment(build,catalog,part,item.id);$('equipmentSearch').value='';render();$('gearDialog').close();$('selectionMessage').textContent=item.name+' équipé.'};target.append(button);
 }
 if(!list.length)target.append(el('p','','Aucune pièce ne correspond. Effacez la recherche ou changez les filtres.'));
 $('gearMore').hidden=list.length<=pickerLimit;
}
