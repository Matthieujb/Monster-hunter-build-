import {optimizeEquipment} from './build-optimizer.mjs';
import {optimizeDecorations} from './builder-features.mjs';
self.onmessage=({data})=>{try{const {kind,build,catalog,goals,lockedParts}=data;const result=kind==='equipment'?optimizeEquipment(build,catalog,goals,{limit:20,gemLimit:100,lockedParts}):optimizeDecorations(build,catalog,goals,{limit:500});self.postMessage({result})}catch(error){self.postMessage({error:error.message})}};
