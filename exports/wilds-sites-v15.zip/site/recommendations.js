/* Contextual ranking of legal single-item replacements; not an exhaustive optimizer. */
(()=>{
const q=s=>document.querySelector(s);
function weight(s){const n=(s.english||'').toLowerCase(),goal=q('#buildForm').elements.goal.value,type=q('#buildWeaponType').value;let w=1;
if(/attack boost|critical eye|critical boost|weakness exploit|agitator|burst/.test(n))w=goal==='Dégâts'?5:3;
if(/evade window|evade extender|earplugs|divine blessing|recovery/.test(n))w=goal==='Confort & survie'?5:2;
if(/wide.range|speed eating|free meal/.test(n))w=goal==='Soutien'?5:1;
if(/slugger|stamina thief|paralysis attack/.test(n))w=goal==='KO & contrôle'?5:1;
if(/slugger/.test(n)&&!['hammer','hunting-horn','light-bowgun','heavy-bowgun'].includes(type))w=0;
if(/element attack|fire attack|water attack|ice attack|thunder attack|dragon attack|critical element/.test(n))w=goal==='Élémentaire'?5:1;
if(/bow charge|normal shots|spread.*shots|piercing shots/.test(n)&&!['bow','light-bowgun','heavy-bowgun'].includes(type))w=0;
return w}
function analyze(part,item){const gear={...currentGear,[part]:String(item.id)};const totals=collectSkillTotals(gear,placements);const before=collectSkillTotals(currentGear,placements);const base=new Map(before.map(s=>[String(s.id||s.name),s]));const after=new Map(totals.map(s=>[String(s.id||s.name),s]));let gain=0;const changes=[];
for(const key of new Set([...base.keys(),...after.keys()])){const a=after.get(key),b=base.get(key),delta=(a?.effective||0)-(b?.effective||0);if(delta){gain+=delta*weight(a||b);changes.push({name:(a||b).name,delta})}}
const old=selectedGear(part),slots=item.slots||[],oldSlots=old?.slots||[];const slotGain=slots.reduce((n,v)=>n+Number(v),0)-oldSlots.reduce((n,v)=>n+Number(v),0);const defense=(item.defense?.base||0)-(old?.defense?.base||0);return {item,gain,score:gain+slotGain*.65+defense*.025,slotGain,defense,changes}}
function legal(part,item){const group=gearParts.find(p=>p[0]===part)?.[2];return placements.filter(p=>p.part===part).every(p=>{const j=jewelById(p.decorationId);return j&&j.kind===group&&Number(item.slots?.[p.slot]||0)>=Number(j.slot)})}
function show(dialog,part){let panel=dialog.querySelector('.matchPanel');if(!panel){panel=document.createElement('section');panel.className='matchPanel';const target=dialog.querySelector('#armorResults,#compactResults');target.before(panel)}
if(!part){panel.hidden=true;return}panel.hidden=false;
const current=selectedGear(part);let pool=part==='weapon'?allWeapons.filter(w=>w.kind===(q('#compactCategory')?.value||q('#buildWeaponType').value)):part==='charm'?getCharmRanks():armor.filter(a=>a.kind===part);
// Keep weapon suggestions in the current category and element/status family.
if(part==='weapon'&&current)pool=pool.filter(w=>w.kind===current.kind&&JSON.stringify((w.elements||[]).map(e=>e.kind).sort())===JSON.stringify((current.elements||[]).map(e=>e.kind).sort()));
const candidates=pool.filter(a=>String(a.id)!==String(current?.id)&&legal(part,a)).map(a=>analyze(part,a)).sort((a,b)=>b.score-a.score||String(a.item.name).localeCompare(b.item.name,'fr')).slice(0,4);
panel.innerHTML=`<div class="matchHeading"><b>✦ Suggestions pour votre build</b><small>${esc(q('#buildForm').elements.goal.value)}</small></div><p>Classement indicatif : talents utiles, niveaux plafonnés, emplacements et défense. Les joyaux déjà sertis sont conservés. Les bonus de set, renforcements et dégâts réels ne sont pas optimisés ici.</p>${candidates.length?candidates.map((r,i)=>`<article><div><b>${esc(r.item.name)}</b><small>${r.score>0?'Amélioration du score de compatibilité': 'Alternative · compromis à vérifier'} · ${r.slotGain>=0?'+':''}${r.slotGain} capacité cumulée des emplacements${part!=='weapon'?` · ${r.defense>=0?'+':''}${r.defense} défense de base`:''}</small><p>${r.changes.length?r.changes.map(c=>`<span class="${c.delta>0?'matchGain':'matchLoss'}">${c.delta>0?'+':''}${c.delta} ${esc(c.name)}</span>`).join(' '):'Talents inchangés'}</p></div><button type="button" data-match="${i}">Équiper</button></article>`).join(''):'<p>Aucune alternative compatible avec vos joyaux actuels.</p>'}`;
panel.querySelectorAll('[data-match]').forEach(b=>b.onclick=()=>{const item=candidates[Number(b.dataset.match)].item;if(!legal(part,item))return;if(part==='weapon'){q('#buildWeaponType').value=item.kind;populateWeaponChoice(false)}const select=q('#gear_'+part);if(!select)return;select.value=String(item.id);select.dispatchEvent(new Event('change',{bubbles:true}));persistDraft();dialog.close();q('#compactWeapon')?.focus()})}
function partFor(dialog){if(dialog.classList.contains('compactPicker'))return q('#categoryLabel')?.hidden?null:'weapon';const title=dialog.querySelector('h2')?.textContent||'';return gearParts.find(([id,label])=>title.endsWith(': '+label))?.[0]||null}
for(const dialog of document.querySelectorAll('.armorPicker')){new MutationObserver(records=>{if(records.some(r=>r.attributeName==='open')&&dialog.open)show(dialog,partFor(dialog))}).observe(dialog,{attributes:true,attributeFilter:['open']});dialog.querySelector('#compactCategory')?.addEventListener('change',()=>show(dialog,partFor(dialog)))}
})();
