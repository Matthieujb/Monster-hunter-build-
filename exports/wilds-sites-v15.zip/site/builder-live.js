function renderHunterHUD(){
 const root=document.querySelector('#skillConstellation');if(!root)return;
 const totals=collectSkillTotals(currentGear,placements);
 root.innerHTML='<div class="treeRoot" aria-hidden="true">✥</div>'+(totals.length?'<div class="talentNodes">'+totals.map((s,i)=>{const rec=skills.find(r=>r.id===s.id),rank=rec?.ranks?.find(r=>r.level===s.effective)||rec?.ranks?.[s.effective-1];return `<details class="talentNode ${s.effective===s.max?'maxed':''}"><summary><span class="talentOrb">${String(i+1).padStart(2,'0')}</span><b>${esc(s.name)}</b><small>Nv ${s.effective} / ${s.max}</small><span class="rankDots" aria-hidden="true">${Array.from({length:Math.min(s.max,10)},(_,j)=>`<i class="${j<s.effective?'lit':''}"></i>`).join('')}</span></summary><p>${esc(rank?.description||rec?.description||'Description non renseignée dans la fiche.')}${s.level>s.max?`<br>Total ${s.level} : niveau effectif plafonné à ${s.max}.`:''}</p></details>`}).join('')+'</div>':'<div class="treeEmpty"><span>◇</span><h3>Le potentiel de votre set</h3><p>Sélectionnez votre équipement.<br>Ses talents s’illumineront ici.</p></div>');
 const armorParts=['head','chest','arms','waist','legs'].map(p=>selectedGear(p)).filter(Boolean),def=armorParts.reduce((n,a)=>n+(Number(a.defense?.base)||0),0),slots=gearParts.reduce((n,[id])=>n+getGearSlots(id).length,0);
 document.querySelector('#hudStats').innerHTML=`<div><small>DÉFENSE DE BASE</small><b>${armorParts.length?def:'—'}</b><span>${armorParts.length}/5 pièces</span></div><div><small>TALENTS ACTIFS</small><b>${totals.length.toString().padStart(2,'0')}</b><span>équipement + joyaux</span></div><div><small>JOYAUX SERTIS</small><b>${placements.length}<em> / ${slots}</em></b><span>emplacements du set</span></div>`;
 document.querySelector('#hudBuildName').textContent=document.querySelector('#buildForm').elements.title.value||'Nouveau set';
}
const previousBuildSkills=renderBuildSkills;
renderBuildSkills=function(){previousBuildSkills();renderHunterHUD()};
renderHunterHUD();
