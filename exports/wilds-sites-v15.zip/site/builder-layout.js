(() => {
 const q=s=>document.querySelector(s), form=q('#buildForm');
 q('.atelierHero').innerHTML='<div><a class="breadcrumb" href="index.html">CARNET DE CHASSE / ATELIER</a><p class="eyebrow">MONSTER HUNTER WILDS</p><h1>Votre équipement.<br><em>Votre signature.</em></h1></div><p class="hudIntro">Préparez le set.<br>Révélez son potentiel.</p>';
 const saved=q('#carnet>div'); saved.className='buildArchive';
 saved.querySelector('h2').innerHTML='Mes configurations';
 saved.querySelectorAll('p:not(.eyebrow),.note').forEach(n=>{if(!n.closest('#saved'))n.remove()});
 q('#carnet').append(saved);
 const nodes=[...form.children],left=document.createElement('div'),right=document.createElement('div'),bottom=document.createElement('div');
 left.className='hudEquipment';right.className='hudAnalysis';bottom.className='hudSave';
 let zone=left;
 for(const n of nodes){if(n.id==='gemmes')zone=right;if(n.id==='talents')zone=right;if(n.tagName==='LABEL'&&n.querySelector('textarea'))zone=bottom;zone.append(n)}
 form.append(left,right,bottom);
 const summary=q('#buildSkillSummary'), heading=q('#talents');right.prepend(summary);right.prepend(heading);
 heading.querySelector('h3').textContent='Constellation des talents';
 const tree=document.createElement('div');tree.id='skillConstellation';tree.setAttribute('aria-live','polite');heading.after(tree);
 const guide=document.createElement('p');guide.className='treeNote';guide.textContent='Vue des talents cumulés. Les liens sont décoratifs : aucun point à débloquer.';tree.after(guide);
 const stats=document.createElement('div');stats.id='hudStats';left.querySelector('.panelHeading').after(stats);
 const emblem=document.createElement('div');emblem.className='hunterEmblem';emblem.innerHTML='<span aria-hidden="true">✥</span><div><small>CONFIGURATION ACTIVE</small><strong id="hudBuildName">Nouveau set</strong><p>Arme · Armure · Talisman</p></div>';left.prepend(emblem);
 q('.workbenchNav').innerHTML='<a href="#carnet">ÉQUIPEMENT</a><a href="#talents" class="hudActive">TALENTS</a><a href="#gemmes">JOYAUX</a><a href="#degats">STATISTIQUES</a>';
 q('.workbenchNav').addEventListener('click',e=>{const a=e.target.closest('a');if(a){q('.hudActive')?.classList.remove('hudActive');a.classList.add('hudActive')}});
 form.elements.title.addEventListener('input',()=>q('#hudBuildName').textContent=form.elements.title.value||'Nouveau set');
})();
